# Tutorial Dasar PHP
## Studi Kasus Forum

Gunakan `forum.sql` untuk membuat table di database

- [Form Registrasi User](https://www.myphptutorials.com/tutorials/11/studi-kasus-forum-form-registrasi-user)
- [Login & Logout](https://www.myphptutorials.com/tutorials/12/studi-kasus-forum-form-login-user-log-out-sistem)
- [Posting Topik atau Pertanyaan Baru](https://www.myphptutorials.com/tutorials/13/studi-kasus-forum-posting-topik-atau-pertanyaan-baru)
- [Menampilkan & Tambah Komentar](https://www.myphptutorials.com/tutorials/14/studi-kasus-forum-menambah-komentar-menampilkan-komentar-atau-jawaban)
- [Halaman Profil User dan Ganti Password](https://www.myphptutorials.com/tutorials/17/studi-kasus-forum-halaman-profil-user-dan-ganti-password)
- [Hapus Topik dan Komentar](https://www.myphptutorials.com/tutorials/1553/studi-kasus-forum-hapus-topik-dan-komentar)
